// lib/audioManager.ts
type TrackName = 'rain' | 'thunder' | 'fire' | string;

class AudioManager {
  private ctx = new (window.AudioContext || (window as any).webkitAudioContext)();
  private tracks: Record<TrackName, {
    buffer?: AudioBuffer;
    source?: AudioBufferSourceNode;
    gain?: GainNode;
    isPlaying: boolean;
  }> = {};

  /** Загрузка трека (запускаем один раз при старте) */
  async load(name: TrackName, url: string) {
    const res = await fetch(url);
    const data = await res.arrayBuffer();
    const buffer = await this.ctx.decodeAudioData(data);
    this.tracks[name] = { buffer, isPlaying: false };
  }

  /** Воспроизведение/пауза */
  toggle(name: TrackName) {
    const t = this.tracks[name];
    if (!t?.buffer) return;

    if (t.isPlaying) {
      t.source?.stop();
      t.isPlaying = false;
      return;
    }

    const src = this.ctx.createBufferSource();
    const gain = this.ctx.createGain();
    src.buffer = t.buffer;
    src.loop = true;
    src.connect(gain).connect(this.ctx.destination);
    src.start(0);

    t.source = src;
    t.gain = gain;
    t.isPlaying = true;
  }

  /** Громкость 0–1 */
  setVolume(name: TrackName, v: number) {
    this.tracks[name]?.gain?.gain.setValueAtTime(v, this.ctx.currentTime);
  }

  /** Громкость всех */
  setVolumeAll(v: number) {
    Object.values(this.tracks).forEach(t => t.gain?.gain.setValueAtTime(v, this.ctx.currentTime));
  }

  /** Стоп всех */
  stopAll() {
    Object.values(this.tracks).forEach(t => {
      if (t.isPlaying) t.source?.stop();
      t.isPlaying = false;
    });
  }
}

export const audioManager = new AudioManager();
